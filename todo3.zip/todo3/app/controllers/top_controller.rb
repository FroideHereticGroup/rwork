class TopController < ApplicationController
  def index
    render "about"
  end

  def about
  end

  def help
  end
end
