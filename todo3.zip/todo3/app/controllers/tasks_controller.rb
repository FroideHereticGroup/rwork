class TasksController < ApplicationController
  def index
    @tasks = Task.all
  end

  def new
    @task = Task.new
  end

  def edit
  end

  def create
    parms.permit!
    @task = Task.new(params[:task])    #最初に入れた入力を元にインスタンスを生成
    if @task.save   #DBへの保存（自動的にINSERTが発行される）
      redirect_to tasks_url
    else  #保存できなかった時
      render :action => :new  #新しい画面に戻っても前に入力した情報を保持している
    end
  end
end
